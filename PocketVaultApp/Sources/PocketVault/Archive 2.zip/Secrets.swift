import Foundation

/// Local-only secrets. This file is listed in .gitignore and must NEVER be
/// committed to a public (or otherwise unauthorized) repository.
///
/// If you're cloning this repo fresh: copy `Secrets.example.swift`, rename
/// the copy to `Secrets.swift`, and fill in the real value below — it has
/// to match whatever `x-app-secret` your Supabase edge function proxy
/// expects (see SECURITY_NOTES.txt).
enum Secrets {
    static let appSharedSecret = "vault_secret_998877"
}
