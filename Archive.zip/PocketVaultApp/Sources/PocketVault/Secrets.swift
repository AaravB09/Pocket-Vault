// Intentionally empty. Never put provider API keys, Supabase service-role
// keys, or reusable "app secrets" in a mobile binary. Those belong in
// Supabase Edge Function secrets only.
