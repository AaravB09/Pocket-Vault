import SwiftUI

public struct GoalPreset: Identifiable {
    public let id = UUID()
    let name: String
    let icon: String
    // Skip/Android has no equivalent for "cpu", "car.side", or "shield" —
    // see PlatformSymbol.swift — so each preset carries its own Android
    // stand-in rather than falling back to the warning-triangle glyph.
    let androidIcon: String
    let defaultAmount: Double
    let defaultMonths: Int // smart default: typical timeframe for this kind of goal
}

/// The screens of the setup flow, in order. Each is a single focused
/// question — matching Clucky's one-question-per-screen onboarding
/// rather than one long scrolling form.
///
/// No dedicated date step: the target date already gets a sensible
/// default the moment a goal or preset is picked (see the preset button
/// and applySuggestion() below), and fine-tuning it matters mostly for
/// Pro features like calendar sync and AI coaching pace — not something
/// worth a whole onboarding screen for every user. It stays editable
/// later from wherever goal details are shown.
public enum SetupStep: Int, CaseIterable {
    case goal, amount
}

public struct SetupGoalView: View {
    @Environment(\.dismiss) var dismiss: DismissAction
    @EnvironmentObject var theme: ThemeManager
    @EnvironmentObject var authManager: AuthManager

    @Binding var goalTitle: String
    @Binding var goalKindRaw: String
    @Binding var targetGoal: Double
    @Binding var currentSavings: Double
    @Binding var targetDate: Date
    // JSON blueprint for an AI-generated custom sculpture — see
    // Goal.customVoxelBlueprintJSON. Written back here on confirm so a
    // custom goal like "cat food" keeps looking like cat food instead of
    // silently reverting to the generic gift box.
    var customVoxelBlueprint: Binding<String?> = .constant(nil)

    var isOnboarding: Bool = false
    var onSave: (() -> Void)? = nil

    @State private var step: SetupStep = .goal

    // Smart defaults: most people never touch these, so the first (and
    // most common) preset is pre-selected rather than starting blank.
    @State private var selectedPresetName: String = "Plane Ticket to Mexico"
    @State private var amountText: String = "1200"

    // AI custom goal builder — free-text description in, a concrete
    // suggested title/amount/timeframe out. Lets goals like "a weekend
    // trip" or "something for this week" resolve to a realistic
    // short-term plan instead of being forced into the fixed presets
    // below, which all skew toward multi-month goals.
    @State private var customGoalDescription: String = ""
    @State private var isGeneratingSuggestion: Bool = false
    @State private var aiSuggestion: AIGoalBuilderService.Suggestion?
    @State private var aiErrorMessage: String?

    // Tracks which GoalKind (and therefore which 3D build) the current
    // selection maps to. Presets set this directly from their known kind;
    // the AI path sets it from the model's classification instead of
    // re-deriving it from the title text, which would otherwise always
    // land on .custom for anything the model names.
    @State private var resolvedGoalKind: GoalKind = .custom

    // JSON blueprint for a bespoke AI-generated sculpture — only set (and
    // only used) when resolvedGoalKind is .custom and the model actually
    // pictured a specific shape for the item. Cleared whenever a preset
    // is chosen instead, since presets always use a fixed GoalKind build.
    @State private var resolvedVoxelBlueprintJSON: String? = nil

    let presets: [GoalPreset] = [
        GoalPreset(name: "Plane Ticket to Mexico", icon: "paperplane", androidIcon: "paperplane", defaultAmount: 1200, defaultMonths: 4),
        GoalPreset(name: "Gaming Rig", icon: "cpu", androidIcon: "gearshape.fill", defaultAmount: 1500, defaultMonths: 3),
        GoalPreset(name: "New Car", icon: "car.side", androidIcon: "cart.fill", defaultAmount: 8000, defaultMonths: 18),
        GoalPreset(name: "Emergency Fund", icon: "shield", androidIcon: "lock.fill", defaultAmount: 1000, defaultMonths: 6)
    ]

    private var isAmountValid: Bool {
        guard let value = Double(amountText) else { return false }
        return value > 0
    }

    private var amountBinding: Binding<Double> {
        Binding(
            // NOTE(skip): bare `?? 0` here left the Elvis operator's two
            // branches as Double and Int, which Kotlin can't unify — it
            // infers `Number & Comparable<CapturedType(*)>` instead of
            // Double, which then surfaces as several different-looking
            // errors (return type mismatch, argument type mismatch)
            // depending on where the type checker catches it. Same fix
            // as elsewhere in the app: spell out the Double literal.
            get: { Double(amountText) ?? 0.0 },
            set: { amountText = "\(Int($0.rounded()))" }
        )
    }

    private var currentStepIndex: Int { SetupStep.allCases.firstIndex(of: step) ?? 0 }
    private var totalSteps: Int { SetupStep.allCases.count }

    // Only the amount step has a real validity gate — a goal always has a
    // default preset selected, so it's "valid" the moment you land on it.
    private var isStepValid: Bool {
        switch step {
        case .goal: return true
        case .amount: return isAmountValid
        }
    }

    private var ctaTitle: String {
        switch step {
        case .goal: return "Continue"
        case .amount: return isOnboarding ? "Begin" : "Save journey"
        }
    }

    public var body: some View {
        ZStack {
            VStack(spacing: 0.0) {
                header

                ScrollView {
                    VStack(spacing: 28.0) {
                        switch step {
                        case .goal: goalStepContent
                        case .amount: amountStepContent
                        }
                    }
                    .padding(Edge.Set.top, 20.0)
                    .padding(Edge.Set.bottom, isOnboarding ? 140.0 : 220.0) // FIXED TYPE INFERENCE HERE
                }
            }

            VStack {
                Spacer()
                pinnedCTA
            }
        }
        // FIX: Replaced `theme` with `ignoresSafeArea: true` to fix the compiler error
        // shown in "Screenshot 2026-08-17 at 9.18.03 PM.jpg"
        .themedSurface(ignoresSafeArea: true)
        .onAppear {
            if !goalTitle.isEmpty, presets.contains(where: { $0.name == goalTitle }) {
                selectedPresetName = goalTitle
            }
            if targetGoal > 0 {
                amountText = "\(Int(targetGoal))"
            }
            if let existingKind = GoalKind(rawValue: goalKindRaw) {
                resolvedGoalKind = existingKind
            }
            resolvedVoxelBlueprintJSON = customVoxelBlueprint.wrappedValue
        }
        .interactiveDismissDisabled(isOnboarding)
    }

    // MARK: - Header (back / progress / skip)

    private var header: some View {
        HStack(spacing: 14.0) {
            // Not a VaultButton: this is a circular icon-only nav control
            // (same shape family as HeaderIconButton in ThemeManager.swift),
            // not a Primary/Secondary/Tertiary/Social CTA — forcing it into
            // VaultButton's 50pt-tall squircle frame would turn it into a
            // rounded square instead of the small circle this header needs.
            Button(action: goBack) {
                Image(systemName: "chevron.left")
                    .font(theme.font(14, weight: Font.Weight.semibold))
                    .foregroundStyle(Color.primary)
                    .frame(width: 34.0, height: 34.0)
                    .background(theme.isLight ? Color.black.opacity(0.05) : Color.white.opacity(0.08))
                    // NOTE(skip): `.clipShape` isn't resolved by Skip's
                    // SwiftUI shim — `.cornerRadius` at half the frame's
                    // width/height renders as the same circle on Android.
                    #if !SKIP
                    .clipShape(Circle())
                    #else
                    .cornerRadius(17)
                    #endif
            }
            .buttonStyle(.plain)

            // FIX (Android "S k i p" vertical letter-stack): this row's
            // middle HStack had no explicit width, and on Compose an
            // un-constrained `Capsule()` with only a `.frame(height:)`
            // doesn't hug its content the way it does in SwiftUI — the
            // three HStack children ended up fighting over the same
            // intrinsic space, squeezing the trailing "Skip" text down
            // to a near-zero-width column that wrapped one letter per
            // line. Giving the progress bar `maxWidth: .infinity` (it's
            // meant to fill the remaining space anyway) and pinning
            // "Skip" to its natural single-line size with `.fixedSize()`
            // resolves the fight on both platforms.
            HStack(spacing: 5.0) {
                ForEach(0..<totalSteps, id: \.self) { i in
                    Capsule()
                        .fill(i <= currentStepIndex ? theme.accent : theme.hairline)
                        .frame(height: 3.0)
                }
            }
            .frame(maxWidth: CGFloat.infinity)

            // Not a VaultButton: an inline text link sitting flush against
            // the step-progress capsules in this tight header row, with no
            // fill/border of its own — VaultButton's fixed height (50pt) and
            // built-in 20pt horizontal padding are sized for a full CTA and
            // would blow out this row's compact layout for no visual gain.
            Button(action: goNext) {
                Text("Skip")
                    .font(theme.font(14, weight: Font.Weight.medium))
                    .foregroundStyle(theme.textSecondary)
                    .fixedSize()
            }
            .buttonStyle(.plain)
        }
        .padding(Edge.Set.horizontal, 20.0)
        .padding(Edge.Set.top, 16.0)
    }

    // MARK: - Pinned CTA

    // During onboarding this view is presented full-screen (.fullScreenCover
    // in Pocket_VaultApp.swift) with nothing below it, so 20pt of bottom
    // padding is enough to clear the home indicator. As the "GOALS" tab,
    // though, it's rendered inline inside MainTabView's own ZStack, and
    // MainTabView draws its floating glass tab bar as a SIBLING on top of
    // that — this view has no way to know the tab bar is there, so without
    // extra clearance the CTA renders right underneath it and becomes
    // unreachable. 100pt clears the tab bar's ~64pt content height plus its
    // padding and shadow with a little room to spare.
    private var ctaBottomPadding: CGFloat { isOnboarding ? 20.0 : 100.0 }

    private var pinnedCTA: some View {
        VStack(spacing: 0.0) {
            LinearGradient(colors: [theme.background.opacity(0), theme.background], startPoint: UnitPoint.top, endPoint: UnitPoint.bottom)
                .frame(height: 36.0)
                .allowsHitTesting(false)

            // MIGRATED: PrimaryCTAButton (ThemeManager.swift) → VaultButton.
            // Same visual family, but PrimaryCTAButton sized itself off
            // vertical padding (17pt) instead of a fixed height, so it
            // drifted a pixel or two from every other CTA depending on the
            // label's font metrics — VaultButton fixes that with a shared
            // `.frame(height: Layout.height)`. It also already renders its
            // own flat neutral-grey fill whenever `isEnabled` is false, so
            // the old by-hand `isStepValid ? theme.accent : theme.accent
            // .opacity(0.3)` dimming is redundant now — `.disabled(...)`
            // alone drives that, same simplification already made at the
            // ForgotPasswordSheet call site in Loginview.swift. Label is
            // passed as `AnyView` (not a trailing ViewBuilder closure) so
            // this keeps working under Skip/Android — see VaultButton.swift.
            VaultButton(
                variant: .primary,
                action: goNext,
                label: AnyView(
                    HStack(spacing: 8.0) {
                        Text(ctaTitle)
                        if step != .amount {
                            Image(systemName: "arrow.forward")
                        }
                    }
                )
            )
            .disabled(!isStepValid)
            .animation(Animation.easeInOut(duration: 0.2), value: isStepValid)
            .padding(Edge.Set.horizontal, Layout.pageMargin)
            .padding(Edge.Set.bottom, ctaBottomPadding)
            .background(theme.background)
        }
    }

    private func goNext() {
        // NOTE(skip): UIImpactFeedbackGenerator isn't safe to actually
        // invoke on Android — it compiles under Skip but crashes at
        // runtime when `impactOccurred()` is called. Same guard used
        // everywhere else in the app (see AmountScrubPicker,
        // BuildStudioView, MainTabView, etc.) — this one was missing,
        // which is why the "Continue" button on the Goal step force-
        // closed the app on Android.
        #if !SKIP
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        #endif
        if let idx = SetupStep.allCases.firstIndex(of: step), idx < totalSteps - 1 {
            withAnimation(Animation.spring(response: 0.35, dampingFraction: 0.85)) {
                step = SetupStep.allCases[idx + 1]
            }
        } else {
            confirmGoal()
        }
    }

    private func goBack() {
        #if !SKIP
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        #endif
        if let idx = SetupStep.allCases.firstIndex(of: step), idx > 0 {
            withAnimation(Animation.spring(response: 0.35, dampingFraction: 0.85)) {
                step = SetupStep.allCases[idx - 1]
            }
        } else {
            dismiss()
        }
    }

    // MARK: - Step 1: Goal

    private var goalStepContent: some View {
        VStack(spacing: 28.0) {
            VStack(spacing: 6.0) {
                SectionLabel(isOnboarding ? "Choose your destination" : "Update journey")

                Text("What are you building toward?")
                    .font(theme.font(22, weight: Font.Weight.semibold))
                    .foregroundStyle(Color.primary)
            }

            aiGoalCard
                .padding(Edge.Set.horizontal, Layout.pageMargin)

            HStack {
                Rectangle().fill(theme.hairline).frame(height: 1.0)
                Text("or pick a quick preset")
                    .font(theme.font(12, weight: Font.Weight.medium))
                    .foregroundStyle(theme.textTertiary)
                    .fixedSize()
                Rectangle().fill(theme.hairline).frame(height: 1.0)
            }
            .padding(Edge.Set.horizontal, Layout.pageMargin)

            // NOTE: the row content used to be inlined directly in this
            // ForEach's closure. With everything (Button, action closure,
            // HStack, background/overlay chain) inline, the type-checker
            // couldn't solve the whole expression in one pass and fell back
            // to matching the wrong ForEach initializer overload (the
            // Binding<Data>-based "editable list" one), which surfaced as
            // "Cannot convert value of type '[GoalPreset]' to expected
            // argument type 'Binding<C>'" even though `presets` is a plain
            // array. Extracting the row into `presetRow(for:)` below keeps
            // this closure trivial so the real (plain-array) ForEach
            // overload resolves correctly.
            VStack(spacing: 12.0) {
                ForEach(presets) { preset in
                    presetRow(for: preset)
                }
            }
            .padding(Edge.Set.horizontal, Layout.pageMargin)
        }
    }

    // Not a VaultButton: this is a selectable list row rendered as a full
    // `Capsule()` (pill), the same "different shape family, deliberately
    // left alone" call already made for ThemePickerSection's appearance-mode
    // rows in ThemeManager.swift — it's a persistent multi-option selector,
    // not a one-shot CTA, so it keeps its own pill shape and isSelected-
    // driven fill instead of converging on the squircle CTA family.
    @ViewBuilder
    private func presetRow(for preset: GoalPreset) -> some View {
        let isSelected = selectedPresetName == preset.name
        let presetFillColor: Color = isSelected
            ? theme.accent
            : (theme.isLight ? Color.black.opacity(0.03) : Color.white.opacity(0.03))

        Button(action: {
            selectedPresetName = preset.name
            amountText = "\(Int(preset.defaultAmount))"
            aiSuggestion = nil
            resolvedGoalKind = GoalKind.from(presetName: preset.name)
            resolvedVoxelBlueprintJSON = nil
            // Smart default: seed a realistic target date for this
            // kind of goal instead of leaving "today" selected.
            targetDate = Calendar.current.date(byAdding: Calendar.Component.month, value: preset.defaultMonths, to: Date()) ?? targetDate
            #if !SKIP
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            #endif
        }) {
            HStack(spacing: 14.0) {
                Image.platformSymbol(preset.icon, android: preset.androidIcon)
                    .font(theme.font(16, weight: Font.Weight.light))
                    .foregroundStyle(isSelected ? theme.onAccent : theme.textTertiary)

                Text(preset.name)
                    .font(theme.font(15, weight: Font.Weight.semibold))
                    .foregroundStyle(isSelected ? theme.onAccent : .primary)

                Spacer()

                if isSelected {
                    Image(systemName: "checkmark")
                        .font(theme.font(12, weight: Font.Weight.bold))
                        .foregroundStyle(theme.onAccent)
                }
            }
            .padding(Edge.Set.horizontal, 20.0)
            .padding(Edge.Set.vertical, 16.0)
            // FIX (real root cause): `Capsule().fill(presetFillColor)`
            // passed directly as the `.background(...)` argument doesn't
            // render on Skip/Android — it comes through near-white
            // regardless of presetFillColor's value. Switched to a plain
            // Color background plus a separate `.clipShape(Capsule())`,
            // matching the pattern that already renders correctly
            // elsewhere in this app (MainTabView's LiquidTabButton tab
            // highlight, SavingsTrendChart's range pill).
            .background(presetFillColor)
            .clipShape(Capsule())
            .overlay(
                Capsule()
                    .stroke(isSelected ? Color.clear : theme.hairline, lineWidth: 1.0)
            )
        }
        // NOTE(skip): same root cause as PrimaryCTAButton /
        // SecondaryCTAButton / TertiaryCTAButton in
        // Thememanager.swift — a bare `Button` with no
        // `.buttonStyle` picks up Skip/Compose's default
        // Material button styling on Android, which paints its
        // own (dark/black) container OVER this Button's actual
        // content instead of just wrapping it. Every other
        // custom button in the app already carries
        // `.buttonStyle(PlainButtonStyle())` for exactly this reason; this
        // preset row was the one Button left without it, which
        // is why tapping any goal option here turned solid
        // black on Android instead of showing the theme's
        // accent color.
        .buttonStyle(.plain)
    }

    // MARK: - Step 2: Amount

    private var amountStepContent: some View {
        VStack(spacing: 6.0) {
            SectionLabel("Target value")

            Text("How much are you aiming for?")
                .font(theme.font(22, weight: Font.Weight.semibold))
                .foregroundStyle(Color.primary)
                .padding(Edge.Set.bottom, 24.0)

            AmountScrubPicker(amount: amountBinding)
        }
        .padding(Edge.Set.horizontal, Layout.pageMargin)
    }

    // MARK: - AI Goal Card
    private var aiGoalCard: some View {
        VStack(spacing: 14.0) {
            HStack(spacing: 8.0) {
                Image.platformSymbol("sparkles", android: "star.fill")
                    .foregroundStyle(theme.accent)
                Text("Describe your own goal")
                    .font(theme.font(14, weight: Font.Weight.semibold))
                    .foregroundStyle(theme.accent)
            }

            Text("A weekend trip, a gift, a goal just for this week — say it in your own words.")
                .font(theme.font(12, weight: Font.Weight.light))
                .foregroundStyle(Color.secondary)
                .multilineTextAlignment(TextAlignment.center)

            TextField("", text: $customGoalDescription, prompt: Text("e.g. \"a weekend trip to Tahoe\"").foregroundColor(theme.textTertiary), axis: Axis.vertical)
                .textFieldStyle(.plain)
                .foregroundStyle(Color.primary)
                .font(theme.font(14, weight: Font.Weight.light))
                .padding(14.0)
                // NOTE(skip): `.ultraThinMaterial` and `.clipShape` aren't
                // resolved by Skip's SwiftUI shim — iOS keeps the real
                // material + shape clip, Android gets a plain tinted
                // background + `.cornerRadius`, same pattern used
                // everywhere else in the app.
                #if !SKIP
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 14.0))
                #else
                .background(theme.isLight ? Color.black.opacity(0.04) : Color.white.opacity(0.08))
                .cornerRadius(14)
                #endif
                .overlay(RoundedRectangle(cornerRadius: 14.0).stroke(Color.clear, lineWidth: 1.0))

            // MIGRATED: SecondaryCTAButton (ThemeManager.swift) → VaultButton.
            // `.secondary` already matches SecondaryCTAButton's look
            // (accent-tinted fill + accent border + accent text) and its
            // `isLoading` spinner is tinted to `theme.accent` the same way,
            // but now shares VaultButton's fixed Layout.height instead of
            // SecondaryCTAButton's own 15pt-vertical-padding sizing, so it
            // lines up with every other CTA in the app, including the
            // primary button just below it in this same screen.
            VaultButton(
                "Generate with AI",
                variant: .secondary,
                isLoading: isGeneratingSuggestion,
                action: { Task { await generateSuggestion() } }
            )
            .disabled(customGoalDescription.trimmingCharacters(in: CharacterSet.whitespaces).isEmpty)

            if let aiErrorMessage {
                Text(aiErrorMessage)
                    .font(theme.font(11))
                    .foregroundStyle(theme.danger.opacity(0.9))
                    .multilineTextAlignment(TextAlignment.center)
            }

            if let aiSuggestion {
                suggestionResultCard(aiSuggestion)
            }
        }
        .padding(20.0)
        #if !SKIP
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20.0))
        #else
        .background(theme.isLight ? Color.black.opacity(0.04) : Color.white.opacity(0.08))
        .cornerRadius(20)
        #endif
        .overlay(RoundedRectangle(cornerRadius: 20.0).stroke(theme.accent.opacity(0.3), lineWidth: 1.0))
    }

    private func suggestionResultCard(_ suggestion: AIGoalBuilderService.Suggestion) -> some View {
        let isApplied = selectedPresetName == suggestion.title

        return VStack(spacing: 10.0) {
            HStack {
                Text(suggestion.title)
                    .font(theme.font(15, weight: Font.Weight.semibold))
                    .foregroundStyle(Color.primary)
                Spacer()
                Text("$\(Int(suggestion.suggestedAmount))")
                    .font(theme.font(14, weight: Font.Weight.semibold))
                    .foregroundStyle(theme.accent)
            }

            Text(suggestion.rationale)
                .font(theme.font(11, weight: Font.Weight.light))
                .foregroundStyle(Color.secondary)
                .multilineTextAlignment(TextAlignment.leading)
                .frame(maxWidth: CGFloat.infinity, alignment: Alignment.leading)

            // Not a VaultButton: this has no VaultButtonVariant equivalent —
            // it's a two-state applied/not-applied toggle chip whose fill
            // and text color both flip based on `isApplied`, with no
            // loading state and no full-width CTA sizing. It does reuse
            // Layout.controlRadius + the .continuous clip for shape
            // consistency with the rest of the app (see the NOTE below).
            Button(action: applySuggestion) {
                HStack(spacing: 6.0) {
                    Image(systemName: isApplied ? "checkmark.circle.fill" : "arrow.turn.right.down")
                    Text(isApplied ? "Applied" : "Use this goal")
                }
                .font(theme.font(14, weight: Font.Weight.semibold))
                .frame(maxWidth: CGFloat.infinity)
                .padding(Edge.Set.vertical, 12.0)
                .background(isApplied ? theme.hairline : theme.accent.opacity(0.15))
                .foregroundColor(isApplied ? theme.accent : theme.textPrimary)
                // NOTE(skip): background here is already theme-agnostic,
                // but `.clipShape` itself is still unresolved under Skip.
                #if !SKIP
                .clipShape(RoundedRectangle(cornerRadius: Layout.controlRadius))
                #else
                .cornerRadius(Layout.controlRadius)
                #endif
                .overlay(RoundedRectangle(cornerRadius: Layout.controlRadius).stroke(theme.accent.opacity(isApplied ? 0.5 : 0.2), lineWidth: 1.0))
            }
            .buttonStyle(.plain)
        }
        .padding(14.0)
        .background(theme.isLight ? Color.black.opacity(0.05) : Color.black.opacity(0.2))
        // NOTE(skip): same clipShape-only fix as the button above.
        #if !SKIP
        .clipShape(RoundedRectangle(cornerRadius: 14.0))
        #else
        .cornerRadius(14)
        #endif
    }

    private func generateSuggestion() async {
        guard let accessToken = authManager.accessToken else {
            aiErrorMessage = "Create an account to use AI goal suggestions."
            return
        }
        isGeneratingSuggestion = true
        aiErrorMessage = nil
        aiSuggestion = nil
        do {
            let suggestion = try await AIGoalBuilderService.suggestGoal(from: customGoalDescription, accessToken: accessToken)
            aiSuggestion = suggestion
        } catch {
            aiErrorMessage = error.localizedDescription
        }
        isGeneratingSuggestion = false
    }

    private func applySuggestion() {
        guard let aiSuggestion else { return }
        selectedPresetName = aiSuggestion.title
        amountText = "\(Int(aiSuggestion.suggestedAmount.rounded()))"
        targetDate = Calendar.current.date(byAdding: Calendar.Component.day, value: aiSuggestion.suggestedTimeframeDays, to: Date()) ?? targetDate
        resolvedGoalKind = aiSuggestion.goalKind
        resolvedVoxelBlueprintJSON = aiSuggestion.voxelBlueprintJSON
        #if !SKIP
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        #endif
    }

    private func confirmGoal() {
        goalTitle = selectedPresetName
        goalKindRaw = resolvedGoalKind.rawValue
        targetGoal = Double(amountText) ?? 1200.0
        customVoxelBlueprint.wrappedValue = resolvedVoxelBlueprintJSON
        onSave?()
        // targetDate is already live-bound via the DatePicker above.
        dismiss()
    }
}
