import SwiftUI

/// Shown when someone taps the "reset your password" link from their
/// email. Previously the app had no screen for this at all — the link
/// just quietly signed the person in without ever asking for a new
/// password. This is the missing step: it uses the one-time recovery
/// token AuthManager captured from the link to actually set a new
/// password, then signs the person in.
public struct NewPasswordView: View {
    @EnvironmentObject var authManager: AuthManager
    @EnvironmentObject var theme: ThemeManager
    @Environment(\.dismiss) var dismiss: DismissAction

    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var isSaving: Bool = false
    @State private var errorText: String?

    private struct PasswordRequirement: Identifiable {
        let id = UUID()
        let label: String
        let isMet: (String) -> Bool
    }

    private let requirements: [PasswordRequirement] = [
        PasswordRequirement(label: "At least 6 characters", isMet: { $0.count >= 6 }),
        PasswordRequirement(label: "One uppercase letter", isMet: { $0.contains(where: { $0.isUppercase }) }),
        // NOTE(skip): with bare string-literal bounds ("0"..."9"), Skip's
        // transpiler doesn't apply Swift's contextual String-literal-to-
        // Character inference here, and emits a Kotlin range typed for
        // String — so calling .contains($0) on it, where $0 is a
        // Character, fails ("actual type is 'Char', but 'String' was
        // expected"). Explicit Character(...) bounds fix it (same issue
        // as Loginview.swift's password requirements).
        PasswordRequirement(label: "One number", isMet: { $0.contains(where: { (Character("0")...Character("9")).contains($0) }) })
    ]

    private var isValid: Bool {
        requirements.allSatisfy { $0.isMet(newPassword) } && newPassword == confirmPassword
    }

    public var body: some View {
        ZStack {
            ScrollView {
                VStack(spacing: 24.0) {
                    VStack(spacing: 6.0) {
                        Text("POCKET VAULT")
                            .font(theme.font(11, weight: Font.Weight.bold))
                            .tracking(4)
                            .foregroundStyle(theme.accent)
                        Text("Choose a New Password")
                            .font(theme.font(22, weight: Font.Weight.light))
                            .foregroundStyle(theme.textPrimary)
                    }
                    .padding(Edge.Set.top, 90.0)

                    if let email = authManager.userEmail {
                        Text("Resetting the password for \(email)")
                            .font(theme.font(12, weight: Font.Weight.light))
                            .foregroundStyle(theme.textSecondary)
                            .multilineTextAlignment(TextAlignment.center)
                            .padding(Edge.Set.horizontal, Layout.pageMargin)
                    }

                    VStack(spacing: 14.0) {
                        ZStack(alignment: Alignment.trailing) {
                            Group {
                                if isPasswordVisible {
                                    TextField("", text: $newPassword, prompt: Text("New password").foregroundColor(theme.textTertiary))
                                } else {
                                    SecureField("", text: $newPassword, prompt: Text("New password").foregroundColor(theme.textTertiary))
                                }
                            }
                            .textFieldStyle(.plain)
                            .textInputAutocapitalization(TextInputAutocapitalization.never)
                            .autocorrectionDisabled()
                            .foregroundStyle(theme.textPrimary)
                            .tint(theme.accent)
                            .padding(16.0)
                            .padding(Edge.Set.trailing, 40.0)
                            // NOTE(skip): .ultraThinMaterial has no Android
                            // equivalent and was unresolved, cascading into
                            // the .clipShape right below it too.
                            #if !SKIP
                            .background(.ultraThinMaterial)
                            #else
                            .background(theme.isLight ? Color.white.opacity(0.7) : Color.black.opacity(0.35))
                            #endif
                            .clipShape(RoundedRectangle(cornerRadius: 14.0))
                            .overlay(RoundedRectangle(cornerRadius: 14.0).stroke(Color.clear, lineWidth: 1.0))

                            Button(action: { isPasswordVisible.toggle() }) {
                                Image.platformSymbol(isPasswordVisible ? "eye.slash.fill" : "eye.fill", android: isPasswordVisible ? "lock.fill" : "checkmark.circle")
                                    .font(theme.font(14))
                                    .foregroundStyle(theme.textTertiary)
                            }
                            #if !SKIP
                            .buttonStyle(PlainButtonStyle())
                            #endif
                            .padding(Edge.Set.trailing, 16.0)
                        }

                        SecureField("", text: $confirmPassword, prompt: Text("Confirm new password").foregroundColor(theme.textTertiary))
                            .textFieldStyle(.plain)
                            .textInputAutocapitalization(TextInputAutocapitalization.never)
                            .autocorrectionDisabled()
                            .foregroundStyle(theme.textPrimary)
                            .tint(theme.accent)
                            .padding(16.0)
                            #if !SKIP
                            .background(.ultraThinMaterial)
                            #else
                            .background(theme.isLight ? Color.white.opacity(0.7) : Color.black.opacity(0.35))
                            #endif
                            .clipShape(RoundedRectangle(cornerRadius: 14.0))
                            .overlay(RoundedRectangle(cornerRadius: 14.0).stroke(Color.clear, lineWidth: 1.0))

                        VStack(alignment: HorizontalAlignment.leading, spacing: 8.0) {
                            ForEach(requirements) { requirement in
                                let met = requirement.isMet(newPassword)
                                HStack(spacing: 8.0) {
                                    Image(systemName: met ? "checkmark.circle.fill" : "circle")
                                        .font(theme.font(13))
                                        .foregroundStyle(met ? theme.accent : theme.textTertiary)
                                    Text(requirement.label)
                                        .font(theme.font(12, weight: Font.Weight.light))
                                        .foregroundStyle(met ? theme.textPrimary.opacity(0.8) : theme.textTertiary)
                                }
                            }
                            if !confirmPassword.isEmpty {
                                HStack(spacing: 8.0) {
                                    Image(systemName: newPassword == confirmPassword ? "checkmark.circle.fill" : "circle")
                                        .font(theme.font(13))
                                        .foregroundStyle(newPassword == confirmPassword ? theme.accent : theme.textTertiary)
                                    Text("Passwords match")
                                        .font(theme.font(12, weight: Font.Weight.light))
                                        .foregroundStyle(newPassword == confirmPassword ? theme.textPrimary.opacity(0.8) : theme.textTertiary)
                                }
                            }
                        }
                        .padding(Edge.Set.horizontal, 4.0)
                    }
                    .padding(Edge.Set.horizontal, Layout.pageMargin)

                    if let errorText {
                        Text(errorText)
                            .font(theme.font(12, weight: Font.Weight.light))
                            .foregroundStyle(theme.danger.opacity(0.9))
                            .multilineTextAlignment(TextAlignment.center)
                            .padding(Edge.Set.horizontal, Layout.pageMargin)
                    }

                    VaultButton(
                        "Save new password",
                        variant: VaultButtonVariant.primary,
                        isLoading: isSaving,
                        fontSize: 16.0,
                        action: save
                    )
                    .disabled(!isValid)

                    Spacer(minLength: 40)
                }
            }
        }
        // FIX: Replaced `theme` with `ignoresSafeArea: true`
        .themedSurface(ignoresSafeArea: true)
        .interactiveDismissDisabled(true)
    }

    private func save() {
        isSaving = true
        errorText = nil
        Task {
            do {
                try await authManager.completePasswordReset(newPassword: newPassword)
                dismiss()
            } catch {
                errorText = error.localizedDescription
            }
            isSaving = false
        }
    }
}
